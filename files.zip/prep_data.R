# R/prep_data.R
# Funciones auxiliares de presentación (metadata + tabla).
# La lectura/preprocesamiento de cada dataset se hace manualmente
# en los chunks de index.qmd marcados como "IMPORTAR AQUI".

#' Tarjeta de metadata de una fuente de datos
#'
#' @param nombre     Nombre descriptivo del dataset/planilla
#' @param organismo  Organismo/fuente (ej. "RENAPER", "INDEC")
#' @param cobertura  Cobertura temporal y/o geográfica (ej. "2015-2024, por depto.")
#' @param variables  Variables clave, separadas por coma
#' @param enlace     URL de descarga/consulta pública (o NA si es interno)
#' @param archivo    Ruta relativa al archivo local en data/ (o NA)
fuente_card <- function(nombre, organismo, cobertura, variables,
                         enlace = NA, archivo = NA) {
  filas <- c(
    glue::glue("**Organismo:** {organismo}"),
    glue::glue("**Cobertura:** {cobertura}"),
    glue::glue("**Variables clave:** {variables}")
  )
  if (!is.na(enlace)) {
    filas <- c(filas, glue::glue("**Enlace de descarga:** [{enlace}]({enlace})"))
  }
  if (!is.na(archivo)) {
    filas <- c(filas, glue::glue("**Archivo local:** `{archivo}`"))
  }
  cat(glue::glue("**{nombre}**\n\n"), paste(filas, collapse = "  \n"), "\n")
}

#' Envoltorio estándar para las tablas interactivas del sitio
tabla_interactiva <- function(df) {
  DT::datatable(
    df,
    options = list(scrollX = TRUE, pageLength = 5, dom = "ftip"),
    rownames = FALSE,
    class = "compact stripe hover"
  )
}
